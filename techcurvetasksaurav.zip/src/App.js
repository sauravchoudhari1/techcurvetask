import logo from './logo.svg';
import './App.css';
import ParentComponent from "./components/ParentComponent/index.js"
function App() {
  return (
    <div className="App">
    <ParentComponent></ParentComponent>
    </div>
  );
}

export default App;
